# tylerlengyel.com — tiny site

This folder has a single-file website (`index.html`).
You can host it anywhere (GitHub Pages, Netlify, Vercel, Namecheap hosting, etc.).
